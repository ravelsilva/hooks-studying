import { createContext } from 'react';

const AppContext = createContext(null); //Criando o contexto

export default AppContext;
