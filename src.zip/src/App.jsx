import "./App.css";
import UseReducerDesafio from "./components/Hooks/Desafios/UseReducerDesafio";
import UseCallback from "./components/Hooks/UseCallback";
import UseContext from "./components/Hooks/UseContext";
import UseEffect from "./components/Hooks/UseEffect";
import UseMemo from "./components/Hooks/UseMemo";
import UseReducer from "./components/Hooks/UseReducer";
import UseRef from "./components/Hooks/UseRef";
import UseState from "./components/Hooks/UseState";
function App() {
  return (
    <>
      <UseState />
      <UseEffect />
      <UseRef />
      <UseMemo />
      <UseCallback />
      <UseContext />
      <UseReducer />
      <UseReducerDesafio />
    </>
  );
}

export default App;
